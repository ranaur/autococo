		 DARK CASTLE by kas29
		=======================
You will find a pdf file with the game manual by the author.

Mods I have done to the game:
Time runs, say slowly, with no light but doubles speed when light is ON
You will have THREE matches on every screen, not just one
By default the duration time of a match is 40 units
You can manage that amount pressing
- '2' will increase this amount by 10 (maximum value 150)
- '1' will decrease it by 10 (minimum value 40)
If you turn on the light with a high time value but do not want the time 
to run fast once you have seen the screen details, pressing '3' will
turn the light off and return to time value of 40

Pressing '4' will jump to next level/screen, adding 2 minutes penalty
Pressing 'Q' will pause the game. Any key to continue

You are allowed as much retries as you'd want
The limit is the time. You cannot exceed 9h59m59s (a lot of time)

NOTE. The option retry ('R') is only available while light is *OFF*, so if
you have light on and want to Restart, you need to press '3' before doing that
or wait for the light on time to end ...

enjoy
pere
