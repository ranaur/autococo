		GOBLIN by Hicks (C)2022
		=======================
This game uses keys 'O','P' to move the player left-right and 'Q' to jump
Once we have got the 'beer' we can send 'burps' to the enemies by
pressing SPACE
'A' when staying on Custom blocks will allow the player to cross then 
downwards (these blocks have a white pointed surface on top)
While the game intro advances, we can press SPACE to skip a part.

Controls that I have added to the game:
- INTRO will pause the game, any key to continue
- '3' will step to next screen/level

enjoy
pere
