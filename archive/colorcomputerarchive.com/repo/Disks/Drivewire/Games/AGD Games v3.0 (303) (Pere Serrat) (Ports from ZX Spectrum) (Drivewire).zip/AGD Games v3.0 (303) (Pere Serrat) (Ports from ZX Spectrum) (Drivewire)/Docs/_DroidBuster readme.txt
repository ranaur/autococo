More Energy for the game DroidBuster
------------------------------------
To make the game more forgiveness, you can use this trick

You can try to use higher or lower values at your will.
The procedure is
- Load he DSK/VDK file into computer drive / emulator
- for Dragon
	LOAD"GAMEPM4.BIN":POKE&H2A55,V:EXEC&HE00
- For CoCo
	LOADM"GAMEPM4":POKE&H2A55,V:EXEC&HE00
The default value for V is 9

enjoy
pere
