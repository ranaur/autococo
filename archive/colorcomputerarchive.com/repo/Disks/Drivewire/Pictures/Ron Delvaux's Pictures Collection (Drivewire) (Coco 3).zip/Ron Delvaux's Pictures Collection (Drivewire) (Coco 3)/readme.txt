
Ron Delvaux's Pictures Collection

Highcolor 2 BMP files. The BMP's are 320x200 and included in each DSK is a 
BIN file. The BIN file can be LOADM -ed and executed. The BMP files can be 
opened by using Hicolor2 made by Sock Master.

The files are things I like: bands I like.... and around my home and the cars 
I like and had and have..... and some astro photos I took with my telescopes.

Ron
