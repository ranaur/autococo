
BDS Software CoCo BASIC Quiz Games for Kids (Ages 5 to 105):

ADDITION.DSK:   Mathematics - Addition
SUBTRACT.DSK:   Mathematics - Subtraction
MULTIPLY.DSK:   Mathematics - Multiplication
DIVISION.DSK:   Mathematics - Division

ADVADD.DSK:     Mathematics - Advanced Addition
ADDSUB.DSK:     Mathematics - Advanced Subtraction
ADVMULT.DSK:    Mathematics - Advanced Multiplication
ADVDIV.DSK:     Mathematics - Advanced Division

M. David Johnson
BDS Software
