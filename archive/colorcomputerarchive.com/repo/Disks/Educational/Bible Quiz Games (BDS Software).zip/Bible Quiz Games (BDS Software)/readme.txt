
A BDS Software CoCo BASIC Quiz Game for Kids (Ages 5 to 105):

GENPARTA.DSK:   Bible - Genesis 1-11

M. David Johnson
BDS Software
