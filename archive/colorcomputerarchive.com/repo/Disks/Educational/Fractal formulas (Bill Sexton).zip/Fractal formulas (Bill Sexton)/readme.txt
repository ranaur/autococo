
I have ported these formulas for the CoCo 2.

Mand2 is a simple Mandelbrot set generator in pmode 3.
Key is a simple dragon formula.
Leaf is a simple IFS fractal.
Rug is a simple Sierpiński carpet type formula.

These are freeware. (If that word means anything these days).

Bill Sexton
