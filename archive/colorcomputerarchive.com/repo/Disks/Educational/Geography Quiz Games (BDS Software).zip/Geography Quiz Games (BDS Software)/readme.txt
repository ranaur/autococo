
BDS Software CoCo BASIC Quiz Games for Kids (Ages 5 to 105):

CAPITALS.DSK:   Geography - U.S. State & Territory Capitals
CONTINEN.DSK:   Geography - Continents' Countries and Rivers

M. David Johnson
BDS Software
