USA Quiz

Using the program:

1) Insert/mount USAQUIZ.dsk.  
2) RUN"USA
3) Patiently wait for the program to initialize variables and load in maps


Notes:

I wrote “USA Quiz” for a software competition in Tennessee in the mid 1980s.  It was originally a cassette-based program that I later modified to work on disk systems a year or two later.  I was in Jr. High when I wrote it and migrated it to disk.  


A few acknowledgments:

1) The  code used to generate characters in graphics mode was adapted from “Happy Graphic Holidays”, Rainbow Magazine, December 1983, pages 188-193 by Don Inman.

2) All graphics were traced using the X-PAD.

3) Many thanks to my parents who spent hard-earned money from teachers' salaries to help me build a TRS-80 Color Computer system and buy Rainbow subscriptions. As we’ve heard so many times, this computer was the tool that helped me launch a successful career in technology. 

4) Thanks to my 35-years-later testers from the Facebook TRS-80 Color Computer group that helped correct my spelling of a few states.  I’m still a terrible speller, but today we have spell check!  The version in this zip file has corrected spellings.  Let me know if anyone finds other issues, and I’ll fix them.


Rick Bagwell
Rick@TheBagwells.net
