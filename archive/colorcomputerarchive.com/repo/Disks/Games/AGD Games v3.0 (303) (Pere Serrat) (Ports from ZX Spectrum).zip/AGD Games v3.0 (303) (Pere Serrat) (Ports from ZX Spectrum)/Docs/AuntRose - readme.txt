- � 2021 FRANCESCO FORTE - ALL RIGHTS RESERVED - THIS IS A FREE GAME - EVERY COMMERCIAL DISTRIBUTION 
WITHOUT THE EXPRESS CONSENT OF ITS AUTHOR IS STRICTLY FORBIDDEN
- AUTHORED WITH ARCADE GAME DESIGNER 4.8 - � 2018 JONATHAN CAULDWELL
- THANKS:
JONATHAN CAULDWELL (AGD)
PAUL JENKINSON (AGD TUTORIAL)
ALESSANDRO GRUSSU (TECHNICAL SUGGESTIONS)
DANIELE ZAMBRINI AND LUIGI SERRANTONI ("ZIA ROSA" GAME AUTHORS)

INTRODUCTION
------------
In 1986 Daniele Zambrini and Luigi Serrantoni created the first italian text adventure, "Zia Rosa". 
This is the arcade version (with some modifications...) of that game.

THE GAME
--------
Your aunt Rose is dead. You, her nephew, want to steal her four treasures: 
 
- the insurance policy 
- the pearl necklace 
- the gold bracelet
- the diamonds 
 
The treasures are hidden in her house, but be careful.
You may not be alone...

GAME CONTROLS
-------------
It's possible to redefine the game controls.
Default controls are:

I - LEFT
O - RIGHT
Q - UP / ENTER DOORS
A - DOWN
P - TAKE /LEAVE OBJECTS (you can carry a maximum of four objects at a time)
N - SELECT: you can select one of the objects you are carrying (to use or leave it) or the "OPEN/PUSH" option
M - OPEN/PUSH/USE:
 - to use the selected object (you can use objects individually or on another object you aren't carrying or on furnitures etc.)
 - to open cabinets, push buttons etc. if "OPEN/PUSH" option is selected

Good luck!