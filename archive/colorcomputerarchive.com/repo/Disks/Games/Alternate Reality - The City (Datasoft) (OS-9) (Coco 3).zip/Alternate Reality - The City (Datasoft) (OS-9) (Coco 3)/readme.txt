
This game must be started from a VDG screen/window. Since most 
advanced OS-9 users probably boot into an 80 column term, you 
must either have a vdg descriptor module in memory or know how 
to convert a standard window into a vdg screen. 

Conversion is simple, for example: 

xmode /w1 type=1 pag=16 
shell i=/w1& 

and press CLEAR to access the new window

NOTE: On NitrOS-9 type: xmode /w1 par=1 col=20 row=10 
