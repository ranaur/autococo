AUTOBAHN by Kraig Brockschmidt (from Spectrogram magazine, April 1987).
Requires Coco 1/2 with 32K RAM, and uses Semigraphics-12 (I think), so
it won't display correctly on a Coco 3 (you can make it playable using
the GIME POKE XXXX,XX), but you won't be able to see the # of meters left,
or your score.

NOTE: The original documentation says that you after LOADM "AUTOBAHN", that
you need to do 'EXEC &H7000' to run. You actually just need 'EXEC'. I should 
also mention that the BASIC program is the original program from the magazine 
that POKE's the code in; you don't need to run it at all, but I left it there
to make the DSK image complete from the magazine. You just need the BIN file 
to play.

NOTE: You can try to run this on a Coco 3, by typing POKE 65436,8 before 
typing EXEC. This will screw up the the intro screens a bit, and you won't 
be able to read any of the text on the game play screen (like points and 
score), but the game play should work.

- L. Curtis Boyle -

Original gameplay documentation from the magazine (skipping instructions for
typing in the BASIC program to POKE the game in) follows:
----------------------------------------------------------------------

  Autobahn is a 100% machine language game requiring 32K RAM and one joystick 
  or paddle plugged into the right joystick port. It is position independent 
  as long as memory locations $3800-$3FFF are not used. The game graphics are 
  placed in those locations.
  
  Execution
  
  Enter EXEC to start the game. Upon execution a title screen is shown for 
  about 10 seconds, and then another screen appears. On this screen you may 
  enter your name, but it is not required. When you are finished, press the 
  ENTER key and the game screen appears.
  
  Game Play
  
  When prepared to hit the accelerator, press the right joystick button. The 
  joystick controls your blue "Indy" car seen at the bottom of the screen. 
  But oh, no! Your accelerator is jammed and you cannot slow down! The road 
  begins to rapidly pass by you and the other cars bombard you at high speed. 
  Your goal now is avoiding the other cars (except for those that are totally 
  white, see below). The cars come at you in sets of three--either two slow/one 
  fast or one slow/two fast. The three cars never travel at the same speed and 
  their colors are random.
  
  As you speed along (good thing there aren't police on the Autobahn), your 
  odometer (meters) below your name continually increases. Hitting any car 
  (except white) adds 200 meters, and you hear a blip. For every white car, 
  you get a different sound and 85 points added to your score. Finally for 
  every set of three cars passed, you receive 25 points, regardless if you hit 
  any. Each passing adds about 78 meters to the odometer.
  
  When you reach 10000 meters the game ends. However, if your score is 5000+, 
  you are allowed to drive until 20000 meters. Then if you have 10000+ points 
  at 20000 meters you get another 10000 meters. In short, you need 5000 points 
  for every 10000 meters or the game is over. Note: if you earn, say, 6000 
  points in the first 10000 meters, you still only need 10000+ points by 
  20000 meters, and so on.
  
  One last note: if the car's continual engine sound seems obnoxious (for which
  I do not blame anyone), press the BREAK key at any time in the game and the 
  sound is disabled. Press it any time again to subsequently enable/disable the
  engine sound. The game will run slightly faster with the sound disabled, and 
  the sound of hitting cars cannot be disabled.
  
  I hope you will enjoy this game as I have (during the hundreds of test runs 
  following every small change in the ML code). For a game variation, try to
  attain a low score by colliding with as many colored cars as possible while 
  avoiding the white ones. The lowest possible score is 525, and at one fateful
  instance I only scored 600. I apologize for not including the EDTASM+ editor 
  file for Autobahn, but it is simply too lengthy (800+ lines) to list here. 
  Finally, my thanks to Dave Medley and crew at Spectrogram for producing such 
  a fine magazine.
  