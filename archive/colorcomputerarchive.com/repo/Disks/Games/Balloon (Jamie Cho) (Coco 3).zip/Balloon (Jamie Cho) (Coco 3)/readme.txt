Balloon

You are a ballon on a skateboard that must avoid a pin. This was my first real 
assembly language game and was written around 1988. This game did not use CoCo 3 
graphic modes because I did not know how to access them. After writing this game
I decided to work on something that actually used CoCo 3 graphic modes and did 
not need double buffering.
