Blockdown
=========

by Seismic Brains, 1986

For the Dragon 32, Dragon 64 or Tandy Colour Computer.

16K required.


Loading
-------

Type ``CLOADM`` and press ``ENTER``.


How to play
-----------

From the title page, use ``Left`` and ``Right`` to view other pages: *Controls*,
*Leaderboard* and *Options*. Control is by keyboard, and the keys are shown on
on the *Controls* page.  The *Options* page shows which game parameters may be
altered.  Press ``Space`` to start.

Pieces of various shapes, all formed from four blocks each, will fall from the
top of the screen.  Move and rotate them to complete lines, which will then be
cleared.   Clear more lines at once for higher scores.

Gravity is low to begin with, but steadily increases, increasing the challenge.

The game is over when a piece has no space to appear.
