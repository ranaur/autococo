A&F Software's Chuckie Egg converted for the Tandy CoCo by Stephen J. Woolham.


Changes made to this version:

* Now compatible with Tandy CoCo 1, 2, 3 (Requires 32K RAM + ECB) and Dragon 32/64

* Modified the routine which plays the intro tune and other in-game music to improve sound quality

* Added my own hardware reset handler


Notes:

Extra (fixed) control keys
==========================
DRAGON

Shift + H = Pause (any other key restarts the game)
Shift + A = Abort


COCO

Shift + X = Pause
Shift + Q = Quit



N/B The game plays slightly faster on the US CoCo machines, due to the 60Hz timing.






