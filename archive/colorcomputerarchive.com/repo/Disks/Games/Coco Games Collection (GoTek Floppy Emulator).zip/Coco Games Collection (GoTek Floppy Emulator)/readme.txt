
Coco Games Collection for the GoTek Floppy Emulator
 
Config file is already set. Just copy and paste to a USB stick and plug into 
the GoTek.
