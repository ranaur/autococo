
Dragonfire (PAL 50Hz Coco 2) (Tandy)

It is a patched and slightly modified Dragonfire ROM Pak with PAL 50Hz CoCo2 
video timing. I think that had been done in Australia for the 50Hz PAL CoCo3 
by someone else but I could neither find it here and it is not compatible to 
CoCo1/2. 

The interesting thing about it: I had a few bytes free in the lower-to-upper 
RAM loader, so I squeezed a small intro (under my DEPPELVISION demoer/cracker 
pseudonym) into it, doing other fancy stuff with the VDG including 9-Colors in
PMODE4, on-border graphics and animation, smooth horizontal and vertical 
scrolling. This inspired Simon J. to start demo programming again years ago 
after I had showed, http://www.roust-it.dk/coco/DRAGFIR2.BIN ).

There are a few more changes in the startscreen of the game as well. The same 
file is used today in the CoCo emulator scene to test and/or benchmark emulator 
accuracy (cycle and play-togather of SAM and VDG)

Torsten Dittel
2020-03-04
