
Galax Attax 

This contains both the original 1982 Galax Attax (GALAX.BIN) and the 
"enhanced graphics" version that has the aliens much more closely 
matching the arcade original (GALAX3.BIN).

CoCo 3 required.

L. Curtis Boyle
