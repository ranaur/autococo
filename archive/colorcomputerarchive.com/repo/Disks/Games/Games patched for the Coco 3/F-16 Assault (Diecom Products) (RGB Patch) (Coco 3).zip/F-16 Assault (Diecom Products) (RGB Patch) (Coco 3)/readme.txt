F16 Coco 3 Patched Version
--------------------------

Robert Gault Posted: Oct 31 2006, 04:50 PM   

 Briza,

I have a game disk someone sent me which has F-16.BIN and F-16PRT2.BIN on it. 
It is by Diecom but I'm not sure it is the same version to which you refer. 
In any case, the loading scheme is the same as used for Knockout but not the 
same code. Once patched, the game runs on a Coco3.

For this game, the code checks the address of the data rather than the destination. 
The string of bytes to look for in F-16.BIN (the 3rd sector on my copy) is:

$A7 C0 8C 6F 00 26 F7

Change the 6F00 to 6EEE, which will limit the transfer of data to $FEEE and not 
trash the secondary jump vector table.

It seems my copy of this game was also "cracked" by someone. So, since I don't 
have the original, I can't be sure what will happen with your version. 
