Knockout Coco 3 Patched version
-------------------------------

Robert Gault Posted: Oct 24 2006, 12:35 AM   

After looking at the code, I've found why the program isn't running. It copies data 
from $4000-$7B00 to $C400-$FF00. This works fine on a Coco 1 or 2 but on a Coco3 it 
trashes the secondary jump vectors at $FEEE-$FEFE.

It is possible to patch Knock Out so that it will run on the Coco3. Two bytes in 
T34S15 must be changed from $FF00 to $FEEE.

10 CLEAR512
20 DSKI$0,34,15,A$,B$
30 MID$(A$,23,1)=CHR$(&HFE):MID$(A$,24,1)=CHR$(&HEE)
40 DSKO$0,34,15,A$,B$

The above should do the job.  
