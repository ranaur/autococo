Here you will find what I believe are all the
v3 interactive fiction games that Infocom released
during the 1980’s.

These disk images are ready to play games featuring
an Infocom interpreter that I disassembled and modified
based on the CoCo version D interpreter for use on the
CoCo 3 using the 64 column text mode.

An RGB video display is highly recommended.

These images use the original disk IO routines and will
run from a real floppy drive on your CoCo if you image the
disks.

To play using a CoCo SDC, first mount the game image as
drive 0, and a save disk as desired in drive 1.  Then type
‘RUN@1’ to boot the stock Disk BASIC on the CoCo SDC.

Type ‘DOS’ to run the boot loader, and enjoy!

- Ed Snider
AKA Zippster


25 Infocom adventures are here, dates are first release…

BALLYHOO.DSK    - Ballyhoo, 1985
CUTHROTS.DSK    - Cutthroats, 1984
DEADLINE.DSK    - Deadline, 1982
ENCHANTR.DSK    - Enchanter, 1983
HEARTS.DSK      - Plundered Hearts, 1987 
HOLLYWD.DSK     - Hollywood Hijinx, 1986
HTCHHKER.DSK    - Hitchhikers Guide to the Galaxy, 1984
INFIDEL.DSK     - Infidel, 1983
LEATHER.DSK     - Leather Goddesses of Phobos, 1986
LURKINGH.DSK    - The Lurking Horror, 1987
MINIZORK.DSK    - Mini-ZORK, 1988
MOONMIST.DSK    - Moonmist, 1986
PLANETF.DSK     - Planetfall, 1983
SEASTALK.DSK    - Seastalker, 1984
SORCERER.DSK    - Sorcerer, 1984
SPELLBRK.DSK    - Spellbreaker, 1985
STARCRSS.DSK    - Starcross, 1982
STATIONF.DSK    - Stationfall, 1987
SUSPECT.DSK     - Suspect, 1984
SUSPEND.DSK     - Suspended, 1983
WISHBRNG.DSK    - Wishbringer, 1985
WITNESS.DSK     - Witness, 1983
ZORK_I.DSK      - Zork I, 1980
ZORK_II.DSK     - Zork II, 1981
ZORK_III.DSK    - Zork III, 1982
