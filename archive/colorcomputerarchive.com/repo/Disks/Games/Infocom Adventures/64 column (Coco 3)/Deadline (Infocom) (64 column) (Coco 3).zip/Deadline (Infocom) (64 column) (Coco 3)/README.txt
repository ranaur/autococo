
Deadline - 64 column mode for the Coco 3

This disk image features an Infocom interpreter that I disassembled and 
modified based on the CoCo version D interpreter for use on the CoCo 3 
using the 64 column text mode.

An RGB video display is highly recommended.

This image uses the original disk IO routines and will run from a real 
floppy drive on your CoCo if you image the disk.

To play using a CoCo SDC, first mount the game image as drive 0, and a 
save disk as desired in drive 1.  Then type "RUN@1" to boot the stock 
Disk BASIC on the CoCo SDC.

Type "DOS" to run the boot loader, and enjoy!

- Ed Snider
AKA Zippster
