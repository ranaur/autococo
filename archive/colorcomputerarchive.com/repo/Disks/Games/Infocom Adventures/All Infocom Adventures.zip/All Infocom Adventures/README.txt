
25 Infocom adventures are here, dates are first release…

BALLYHOO.DSK    - Ballyhoo, 1985
CUTHROTS.DSK    - Cutthroats, 1984
DEADLINE.DSK    - Deadline, 1982
ENCHANTR.DSK    - Enchanter, 1983
HEARTS.DSK      - Plundered Hearts, 1987 
HOLLYWD.DSK     - Hollywood Hijinx, 1986
HTCHHKER.DSK    - Hitchhikers Guide to the Galaxy, 1984
INFIDEL.DSK     - Infidel, 1983
LEATHER.DSK     - Leather Goddesses of Phobos, 1986
LURKINGH.DSK    - The Lurking Horror, 1987
MINIZORK.DSK    - Mini-ZORK, 1988
MOONMIST.DSK    - Moonmist, 1986
PLANETF.DSK     - Planetfall, 1983
SEASTALK.DSK    - Seastalker, 1984
SORCERER.DSK    - Sorcerer, 1984
SPELLBRK.DSK    - Spellbreaker, 1985
STARCRSS.DSK    - Starcross, 1982
STATIONF.DSK    - Stationfall, 1987
SUSPECT.DSK     - Suspect, 1984
SUSPEND.DSK     - Suspended, 1983
WISHBRNG.DSK    - Wishbringer, 1985
WITNESS.DSK     - Witness, 1983
ZORK_I.DSK      - Zork I, 1980
ZORK_II.DSK     - Zork II, 1981
ZORK_III.DSK    - Zork III, 1982
