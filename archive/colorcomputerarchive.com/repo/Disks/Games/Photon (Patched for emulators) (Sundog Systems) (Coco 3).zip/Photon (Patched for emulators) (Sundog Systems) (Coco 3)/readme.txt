
Here is a version of Photon that will work on the MAME emulator. It kill's me that this is necessary, 
but I have not been able to get MAME to work with Photon's (game play) joystick routines.

Tim Lindner