
Skiing 6309 optimized

The original cartridge Skiing cartridge game has been converted to 6309, 
but will not gain speed running (since it is VSYNC locked), but, like 
Touchstone, it should render the graphics more quickly & smoothly during 
that time.

L. Curtis Boyle
