
Updated version (V2.0) of Spacewar!
Added sound

There are two files on the swdisk2.dsk:
SPWARV2 is the updated version
SPWARV2N is a version that runs better (i.e. without lag) on COCO3 MAME

Rich