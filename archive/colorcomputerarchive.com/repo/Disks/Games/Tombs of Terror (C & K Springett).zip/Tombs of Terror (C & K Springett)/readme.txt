"Tombs of Terror" - by C & K Springett

This game appeared under the name "Crystal Quest" in issue #28 of "Australian Coco" magazine.
By my calculations this would have been August 1985.

You will notice that the opening title says it is "part one of three". Sorry, but this is the only 
part that was ever written! Therefore there are only 3 crystals to collect so please don't keep trying
to find the rest!

If you find that some of the descriptions pop up too quickly, you can edit line 5500 and change
the for/next loop length to (for example) 3000. I find this happens on the coco 2 - it was written
for a coco 1 by a school kid (me!).

Don't forget to "LOOK" at everything!

Cheers
Craig

