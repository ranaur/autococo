
XENION63.DSK

Xenion (Diecom, Coco 3) 6309 optimized.

XENION3E.DSK

Some people have mentioned that the 6309 optimized version of Xenion is a 
little too fast. This is an alternate 6309 version - it does use TFM 
instructions to speed things up, but stays in 6809 emulation mode (rather 
than native mode, which speeds up some CPU instructions), so it is a little 
slower.

L. Curtis Boyle
