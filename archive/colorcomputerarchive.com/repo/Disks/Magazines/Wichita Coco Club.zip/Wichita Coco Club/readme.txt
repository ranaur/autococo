
Wichita CoCo Club disk collection

Some of these disks may have missing data due to floppy disk errors.  In 
particular, the July 1987 issue may be missing graphics files, and the 
newsletter data file (HUES1187/DAT) may be truncated in the November 1987 
issue.  Perhaps someone else can supply the missing files.  

The disk image 'games__.dsk' is from a disk that lost its label, so I don't 
know what number it originall had in the file library, but it was definitely 
one of the club disks.
