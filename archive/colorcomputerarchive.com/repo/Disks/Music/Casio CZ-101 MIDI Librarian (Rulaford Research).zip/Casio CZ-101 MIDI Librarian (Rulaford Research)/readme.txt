
Files description:

CZ101LIB.DSK 

Casio CZ-101 MIDI Librarian, Rulaford Research

CASIOLIB.DSK

Casio CZ-101 MIDI Librarian, Rulaford Research, with new front end by 
Allen Huffman (and saved CZ-101 stock patches).
