Now you can select among Serial MIDI (to MIDI device), COCO MIDI, and Drivewire4 from the Lyra menu.

There are two versions, one for HDBDOS1.1, the other for HDBDOS1.4.