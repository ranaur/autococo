
To start Musica II type:

LOADM"MUSICA"
EXEC
RUN
