
Disk Programming Package

A must'for any programmer; a necessity for non-programmers who what to make
minor changes to their favorite BASIC programs. This package contains four 
hard-to-find programs.

ADDML automatically appends machine language routines to BASIC programs in a 
  easy, no fuss manner. 
  
UNPACKER undoes the work of program compressors--lets you modify code crunched
  by PACKER or any other program compressor.
  
MLBASIC converts a BASIC program into a machine language file which can be
  LOADMed and EXECed. Includes program encryption and checksum verification. 
  Code is PIC and may be ROMed. 
  
JOIN links several machine language modules together and adds autoexecute if 
  desired.

32K Disk $14.95 


Mapper

100% ML for speed. Cross-reference the variables and line numbers in your BASIC 
programs; find out how many times different variables are used; PLUS string 
search finds all occurrences you input. All output can be sent to the screen or 
printer. If you have ever made a change to a program only to find that the 
variable you added was already used, or deleted a line called by a GOSUB you'll
know why this program is a programmer's joy and a nonprogrammer's
must.

16K Disk $14.95 


Packer

Want to get more memory out of your computer? Want to have your progaras run 
faster? Then this is the utility for you. This 100% ML utility will strip your
BASIC program of unnecessary spaces, colons and LET statements; delete unneeded 
semicolons; remove unneeded GOTOs after THENs and ELSEs; join lines together 
(creating lines much longer than 254 characters); strip out comment lines; and 
fix referenced remark lines. Each option can be used separately. Complete error 
repotting. The result cannot always be edited�an ideal way to protect you code 
from snoopers, especially when combined with MLBA SIC from our Disk Programming
Pack. 

16K Disk $14.95


