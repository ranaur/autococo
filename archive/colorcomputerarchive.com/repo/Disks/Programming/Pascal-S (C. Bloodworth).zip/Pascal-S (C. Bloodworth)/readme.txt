PASCAL-S.DSK   PASCAL-S Distribution Donation-Ware
SOURCE1.DSK    PASCAL-S Source Code
SOURCE2.DSK    PASCAL-S Source Code #2
SOURCE2.DSK    PASCAL-S Source Code #3
TRACE1.DSK     PASCAL-S Tracing Disassembler Work Disk 
TRACE2.DSK     PASCAL-S Tracing Disassembler Work Disk #2
