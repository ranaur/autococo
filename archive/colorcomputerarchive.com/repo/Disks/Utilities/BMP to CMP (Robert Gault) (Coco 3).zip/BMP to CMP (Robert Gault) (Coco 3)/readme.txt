This version of HLOAD converts BMP images to HSCREEN4 images having artifact NTSC colors.
The program does not work with emulators as they don't believe HSCREEN4 can have artifact colors.

The images were preprocessed with Paint Shop Pro to reduce the number of colors to 256, with a width
of 256 or less pixels. Bytes must be 458K or less with a 512K Coco3. The screens are 640x225x4
and are scrolled with a joystick in the right socket.

Be sure to compare the Coco results against the actual .bmp files.

Robert Gault
