
BootPak 1.05
2017 Guillaume Major

BootPak is a partition browser for the MicroSD DrivePak. It is compatible with 
all Cocos and requires 32K. It is based on SideKick by Luis Antoniosi.

Features:
---------

- list partitions on the SD card
- boot partitions
- rename partitions
- assign drives to partitions (/U0 to /U3)
- fast partition selection by the first 4 letters
- sorted partition listing

Command Summary:
----------------

[0-3]:   assign /U# drive to partition
ENTER:   boot partition
SHIFT-R: rename partition
SHIFT-H: show help
BREAK:   quit

Navigational keys:
------------------

SHIFT-UP/DOWN   : Page up/page down
SHIFT-LEFT/RIGHT: Home/End
[A-Z]           : Select next partition matching up to 4 characters 
                  typed quickly 


I hope you will find this program useful. Please contact me if you find a bug 
or have any suggestions!

guillaume.major@gmail.com
