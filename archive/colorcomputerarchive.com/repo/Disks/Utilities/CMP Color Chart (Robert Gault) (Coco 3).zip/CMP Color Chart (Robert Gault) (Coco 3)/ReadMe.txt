CMP Color Chart
     by
Robert Gault

It is easy to understand how RGB colors on a Coco3 are adjusted. The data is stored at $FFB0-$FFBF as follows:
Data Bit      D5   D4   D3   D2   D1   D0
Color         R1   G1   B1   R0   G1   B0
So there are 2^6 colors or 64 total. Each RGB color has 4 intensities.

CMP colors are not intuitive. The format is:
Data Bit      D5   D4   D3   D2   D1   D0
Color         I1   I0   P3   P2   P1   P0
Well there are 2 intensity bits so there are 4 levels of brightness. What do the P values mean?

P is phase and there are 16 levels (2^4). That means you must use a color wheel with colors distributed around the wheel
and intensity increasing from the center out to the circumference. Hmmm, do we need to go back to school?

CMPCHART.BAS for a Coco3 draws the color wheel and when you enter a number 0-63 a small circle is painted with that color.
You will need either a CMP monitor on a Coco3 or an emulator which can switch between CMP and RGB regardless of your actual
monitor.
Start the program and after hitting your number keys, then hit ENTER. The numbers will not show as you type unless you modify
the program.
