Coco Checker +
Coco2
1984
J. Francis


For disk:
LOADM"COCOCHEK.BIN":EXEC

Note:  This program will not operate correctly on a Color Computer 3.
