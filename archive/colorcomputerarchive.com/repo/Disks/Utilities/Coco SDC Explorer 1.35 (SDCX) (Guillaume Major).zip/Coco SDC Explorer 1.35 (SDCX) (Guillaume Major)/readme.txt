
Coco SDC Explorer 1.35
Guillaume Major

SDCX is a file browser for the Coco SDC. It is compatible with all CoCos,
the Dragon 32 and the Dragon 64. SDCX requires 32K. 

Graphics and animation by Erico Patricio Monteiro

SDCX is based on SideKick by Luis Antoniosi.


Features
--------

- list files and directories on the SD card
- create, rename and delete disk images and directories
- mount directories for multi-disks programs
- launch ML and BASIC programs
- detect and boot OS-9 disks
- quick disk and file selection by the first 4 letters
- sorted SDC and disk directory listings
- saves and restores last session
- boot any of the 8 flash banks
- read and write floppy disks (*)
- display floppy disks directory (*)
- format floppy disks (*)
- double sided floppy disks support (*)
- joystick support
- configurable

(*) Color Computer, SDC-DOS, disk controller and MPI required


Command Summary
---------------

SHIFT-C: create disk
SHIFT-K: create directory
SHIFT-N: rename disk or directory
SHIFT-X: delete disk or directroy
SHIFT-1: mount/unmount disk in drive 1 (Coco version)
SHIFT-2: mount/unmount disk in drive 2 (Dragon version)
SHIFT-B: boot flash bank

SHIFT-M: mount directory (multi-disks programs) 
CLEAR:   refresh directory

SHIFT-E: toggle SD card extended view
SHIFT-S: toggle directory sorting
SHIFT-V: toggle RGB/CMP video mode (Coco 3)

SHIFT-R: read floppy disk
SHIFT-W: write floppy disk
SHIFT-D: show floppy drive directory
SHIFT-F: format floppy disk

SHIFT-H: show help

ENTER:   launch program or boot disk
BREAK:   quit


Navigation keys
---------------

LEFT/RIGHT      : Switch between windows
SHIFT-UP/DOWN   : Page up/page down
SHIFT-LEFT/RIGHT: Home/End
[A-Z][0-9]      : Select next file matching up to 4 characters typed quickly 
SHIFT-CLEAR		: SD card root directory


Startup Keys
------------

Hold down the C key at startup to run SDCX configuration program.
Hold down the SPACEBAR at startup to skip the restoration of the last session.


Joystick support
----------------

Press the joystick button of your choice (right of left) to enable joystick.
Press the joystick button to change directory, launch a program or boot a disk.
Press and hold the joystick button to navigate quickly through the lists.


Multi-disks programs
--------------------

SDCX can mount directories with a disk set to support multi-disks programs. 

Press SHIFT-M to mount a directory with a disk set. Files on the first disk 
will appear in the right window.

Press CLEAR to refresh the directory list after switching disk with the button 
on the Coco SDC.


SD Card extended view
---------------------

Press SHIFT-E to toggle SD Card extended view listing. When activated files size 
and attributes are displayed. The extended view will open and close automatically
when the SD card window gets or loses focus.

Attributes:

  A - Archive
  D - Directory
  R - Read only


Configuration
-------------

The first time SDCX is run the configuration program will be invoked.
To run the configuration program at a later time, hold down the C key
at startup or type RUN"CONFIG".

The configuration programs allows you to set the following options:

  - restore last session
  - disable splash screen
  - sort disk directory (directory window)
  - composite video (Coco 3 only)
  - alternate color set (orange text)
  - background color
  - border color (only available when background color is black)

To toggle an option press the associated highlighted letter.
Press ENTER to save the configuration and run SDCX.
Press X to exit the configuration program without saving.


Auto execute SDCX at startup
----------------------------

To run SDCX automatically at startup you need SDC-DOS 1.3 or later. To download
the latest version of SDC-DOS go to http://cocosdc.blogspot.ca/ and click on the 
"Latest Firmeware" link in the Pages menu on the right. Run the SETUP.BAS
program to update your SDC-DOS version.

Copy the SDCX.DSK file to the root of your SD card and rename it to SDCEXP.DSK.

Create or modify your startup.cfg file at the root of your SD card to mount the
SDCEXP.DSK disk in drive 0 or 1 at startup. To do so, add the line #=SDCEXP.DSK 
where # is the drive number. Example:

0=SDCEXP.DSK

With this setup you can now use the EXP command to run SDCX.


Floppy drive commands (Coco only)
---------------------

Floppy drive commands require SDC-DOS, a Multi-Pak Interface, a disk controller 
and a floppy drive. 64K is required on a Coco 1 and Coco 2 for double sided 
disk support. 

Read/Write floppy disks:

Select the disk file you want to use for the read or write operation and press:

SHIFT-R: to copy a floppy disk to the disk file
SHIFT-W: to copy the disk file to a floppy disk

Format floppy disk:

Press SHIFT-F to format a floppy disk.

Options:

0-3:  Drive number selection
T:    Change number of tracks (35, 40 or 80)
S:    Toggle between single, second side and double sided disk
V:    Verify disk (Format command only)

Side(s) option:

  - Single:   Single sided disk
  - Side 2:   Second side of a double sided disk
  - Double:   Double sided disk (OS-9, FLEX)

NOTE: Drive 3 cannot be selected with Side 2 and Double side option.

It is recommended that you use SDC-DOS 1.5 or later for floppy drive operations.
On earlier versions of SDC-DOS, the floppy drive motor would fail to shut-off
after a copy operation.

Floppy disk directory

The floppy disk directory can be displayed with the SHIFT-D command. 
Side selection can be toggled with the S key.


Files description
-----------------

sdcx.dsk     - SDCX Coco version (35 tracks)
sdcx.vdk     - SDCX Dragon version (40 tracks)
readme.txt   - This file
changes.txt  - Changes history


Limitations
-----------

- creates standard .DSK files only (no SDF)
- can only delete empty directories (Coco SDC limitation)
- limit of 400 files per directory

I hope you will find this program useful. Please contact me if you find a bug 
or have any suggestions!

guillaume.major@gmail.com
2022.03.20
