     This set of files will patch RSDOS so that a DSKINI will
not erase any program in memory. The formatted track that is
built in ram now starts at block $34, the HGET/HPUT buffer.
Originally, the track was hard-coded to start at $989, and to
go to $220F, effectively destroying everything in its way.
     Since it now destroys the memory at block $34, you won't
notice it at all, as the buffers are 'cleansed' every time you
RUN a program anyway. Also, it works perfectly on 128K machines,
and may be EPROMable for all I know.
     There are six files in this section, which are as follows:

     1) DSKINI.ARC    all of the following, ARCed with TC3 for
                      your convenience.
     2) DSKINI.SRC    Assembler source code for Macro-80C. Line
                      numbers are included.
     3) DSKINI.ASM    Assembler code for EDTASM+, with comments.
     4) DSKINI.BIN    Binary, assembled version, for RSDOS 1.1
     5) DSKINI0.BIN   as above, but for RSDOS1.0 
                      this version also should work with ADOS3.
     6) DSKINI.DOC    this file.

     Hope you like it!

 Alan DeKok.
------------
