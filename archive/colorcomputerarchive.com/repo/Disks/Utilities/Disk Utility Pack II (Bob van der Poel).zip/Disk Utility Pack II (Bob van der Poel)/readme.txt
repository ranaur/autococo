Disk Utility Pack II

Sixteen great programs for one low price.

ARCHIVE saves an entire disk (35/40 tracks or even OS-9 disks) to tape.

BACKUP is a superfast disk backup utility cutting down the disk swaps to 3
  for a single drive (32/64K and 35/40 track versions included), PLUS a 
  special CoCo 3 Backup which does a whole disk in one pass and then
  allows for multiple copies from the data in memory.
  
FORMAT, a replacement for DSKINI, will save you lots of time (three versions
  included). 
  
FIND searches a disk file for a pattern and reports all occurrences.

COMPARE makes sure two files are identical.

OCCOUNT counts the number of occurrences of a pattern in a disk file.

MENU reads all your drives and displays a sorted directory from which you can
  select your choice with the arrow keys.
  
DSKMATCH verifies that 2 disks are identical�ideal for checking important 
  backups. 
  
All programs configure to CoCo 3 screens if run on a 3, CoCo 2 compatible.

32K Disk $14.95
