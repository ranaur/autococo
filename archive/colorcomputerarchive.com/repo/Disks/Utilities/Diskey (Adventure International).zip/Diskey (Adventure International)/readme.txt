
Diskey by Adventure International
---------------------------------

The original version of Diskey only works with Disk Basic 1.0. I have patched it
to use the DSKCON vector at $C004. It is now compatible with most disk systems 
including Disk Basic 1.1, CoCo SDC, Drivewire and the DrivePak.

Disk listing:

diskey.dsk       - The original version of Diskey which only works with Disk Basic 1.0.
diskey-fixed.dsk - Patched version of Diskey to use the DSKCON vector at $C004.

Enjoy!

Guillaume Major
August 2017
