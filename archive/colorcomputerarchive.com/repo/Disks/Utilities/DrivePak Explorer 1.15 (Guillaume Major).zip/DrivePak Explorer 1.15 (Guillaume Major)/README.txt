
DrivePak Explorer 1.15 (DPX)
2015-2020 Guillaume Major

DrivePak Explorer is a file browser for the MicroSD DrivePak. It is compatible 
with all Cocos and requires 32K. It is based on SideKick by Luis Antoniosi.

Features:
---------

- browse 256 disks DOS partitions
- launch ML and BASIC programs
- find files on DOS partitions
- list and boot partitions
- rename partitions
- assign OS-9 drives to partitions (/U0-/U3)
- fast drive selection by entering digits
- fast file/partition selection by the first 4 letters
- sorted directory and partition listing

Command Summary:
----------------

ENTER:   execute program or boot partition
SHIFT-F: find file
SHIFT-S: toggle directory sorting
SHIFT-V: toggle display of volume for all disks
SHIFT-H: show help
BREAK:   quit

CLEAR:   show partition list
[0-3]:   assign /U# drive to partition
SHIFT-R: rename partition

Navigation keys:
----------------

SHIFT-UP/DOWN   : Page up/page down
SHIFT-LEFT/RIGHT: Home/End
[0-9]           : Quick drive selection
[A-Z]           : Quick file/partition selection


I hope you will find this program useful. Please contact me if you find a bug 
or have any suggestions!

guillaume.major@gmail.com
