                  Drivewire printing with Disk Basic
                               by
                           Robert Gault

    All of these programs assume that the DOS ROM is based on Disk Basic 1.1
If the current ROM is a Disk Basic 1.0, the programs will not work correctly. 
HDBDOS for Drivewire is based on Disk Basic 1.1. The HDBDOS patch is based on
HDBDOS 1.4. Other versions may not work.

    The program.dsk to select will depend on your system. You will either be 
using Disk Basic or HDBDOS for Drivewire. Choose the folder that matches both 
your ROM and your Coco model and extract that disk. Only the Coco3 will be 
running in all RAM mode and the program requires the all RAM mode.

    With a Coco1 or Coco2, you must LOADM"ROMRAM":EXEC. Then LOADM"DWPRINT"
With a Coco3, just LOADM"DWPRINT"

    Once loaded, LLIST and PRINT #-2 .... will send the data to the Drivewire 
printer. You will need to configure Drivewire for your Coco model and have your 
serial Coco to PC cable installed. After loading DWPRINT with HDBDOS as your 
disk ROM, the DIR command will behave normally. To print a directory to DW, you 
must POKE&H6F,&HFE:DIR

With the Disk Basic ROM in use, DIR will always go to the Drivewire printer
after loading DWPRINT. 

    To return to normal Coco operation, you must press the reset button 
(Coco 1 and 2) or restart your Coco either with the power switch or 
CTRL/ALT/RESET (Coco 3).
