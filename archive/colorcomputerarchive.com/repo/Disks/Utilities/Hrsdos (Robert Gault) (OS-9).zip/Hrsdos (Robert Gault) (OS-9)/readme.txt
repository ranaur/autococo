The enclosed is intended for a system using the RGBDOS ROM and enables OS-9 to
access Basic drives on a .vhd plus floppy drives. It should not be too hard to
modify the C program to work with HDBOS variants.
To read Basic drive #253 on a .vhd, the command would be:
hrsdos -dir /H0 :253
