
Key-264K was designed for Disk Basic 1.0 and doesn't work with Disk Basic 1.1.

