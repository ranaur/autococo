OS9Mod is a utility which prints out OS-9: 6809 module header information
for the specified files.  it should be byte-order independant, and has
been compiled on my ReadHat 4.2 Linux system.

This program is public domain.

  Alan DeKok
  Sept. 6, 1997.

