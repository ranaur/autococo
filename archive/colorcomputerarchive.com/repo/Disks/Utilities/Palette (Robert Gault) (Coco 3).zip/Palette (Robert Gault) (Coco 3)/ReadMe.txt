These programs are for the Coco3 only and demonstrate how the palette colors 
should be set for CMP and RGB systems.

PALETTE.BAS can also be used to check the visual timing of emulators, software 
and hardware. Run it on a real Coco3 and compare the results with emulators.

The Coco3 service manual indicates how one calculates both CMP and RGB colors.

Data Bit        D5   D4   D3   D2   D1   D0
Corresponding |
RGB output    | R1   G1   B1   R0   G0   B0
-------------------------------------------
Corresponding |
CMP output    | I1   I0   P3   P2   P1   P0     P=phase

RGB calculation is pretty obvious as it is a mix of four levels of intensity 
for each of Red, Green, and Blue. CMP calculation is not that simple as what 
is meant by phase? Since there are 16 possible phase values 2^4, then possibly 
colors are divided into 360/16=22.5 types with 4 intensity levels. However, 
that does not seem likely rather that it is 360/15=24 for colors with black 
through white as a special case outside the color group.

CMPCHART.BAS gives a graphic description of phase and intensity for CMP colors.

Robert Gault
