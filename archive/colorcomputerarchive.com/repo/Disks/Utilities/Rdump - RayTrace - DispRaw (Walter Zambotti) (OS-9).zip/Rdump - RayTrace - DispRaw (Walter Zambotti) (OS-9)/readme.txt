
OS9 / Nitros9 Utilities

Rdump.

Modified version of rdump that can extract library modules to the current 
directory.  Use the -x option to extract.

Raytrace.  

Heavy double precision maths in C.  The output is NOT really useful except 
for bench marking purposes. 

Disp_Raw.  

Displays a raw image file or frame(s) (with a preset palette) to the screen.  
Reads directly from a disk file to video ram by passing the OS.
Samples frames supplied in separate disk (frames.dsk)

Walter Zambotti
2019
