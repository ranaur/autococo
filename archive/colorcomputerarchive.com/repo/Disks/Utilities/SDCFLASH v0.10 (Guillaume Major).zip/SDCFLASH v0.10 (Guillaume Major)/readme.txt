
SDCFLASH 0.10
Guillaume Major

SDCFLASH is an utility to flash cartridges ROM files into any 
of the 8 available Coco SDC flash bank. It is compatible with 
all CoCos and requires 32K. 

SDCFLASH is based on SideKick by Luis Antoniosi.


Features
--------

- select ROM file to flash with a file browser
- write to any of the 8 available flash banks
- boot flash bank
- quick file selection by the first 4 letters


Command Summary
---------------

SHIFT-B: boot flash bank
SHIFT-S: toggle sorting
SHIFT-V: toggle RGB/CMP video mode (Coco 3)
SHIFT-R: rename ROM set
SHIFT-H: show help

ENTER:   flash bank
BREAK:   quit


Navigation keys
---------------

LEFT/RIGHT      : Switch between windows
SHIFT-UP/DOWN   : Page up/page down
SHIFT-LEFT/RIGHT: Home/End
[A-Z][0-9]      : Select next file matching up to 4 characters typed quickly 


Flashing ROM files
------------------

Select a ROM set from the left window using the navigation keys and press the
right arrow to access the ROM file list. Select the ROM file to flash and press
ENTER.

Type the bank number to flash (0-7) and press ENTER. A confirmation dialog will
be displayed. Press Y to proceed, N or BREAK to cancel the operation.

NOTE: The active SDC bank cannot be flashed. 


ROM files
---------

ROM files on this disk are not loadable or executable. They are raw binary dumps 
of the chips inside cartridges. SDCFLASH comes with over 140 ROM files divided 
into 17 ROM sets.

The SDCFLASH disk is an HDB-DOS image containing several RS-DOS 35 tracks disks. 
Each disk represent a ROM set. At startup SDCFLASH will browse all disks in the 
HDB-DOS image to read each disk name. The list of disks found will be displayed 
into the ROM sets window.

ROM files must have the ROM extension to be displayed in the ROMS window. The
maximum ROM file size that can be flashed into the Coco SDC is 16KB.


Adding your own ROM files
-------------------------

ROM set disks can be accessed with the DRIVE 0,NUM command where NUM represents 
the index of the disk. ROM files can then be added with standard RS-DOS commands
or with a file copying utility.

SDCFLASH comes with 17 disks of ROM files. To add a new disk to the set, type 
the following commands:

  - DRIVE 0,NUM    where NUM is the new disk number (example: 18)
  - DSKINI0

Use the SHIFT-R command to rename the newly created disk. Increase the disk 
number to add other ROM set disks.


Renaming ROM sets
-----------------

Select the ROM set to rename and press SHIFT-R. Type the new name for the ROM set
and press ENTER when done. To clear the ROM set name press SHIFT-LEFT.

If the disk has no name DRIVE #NUM will be displayed where NUM is the number of
the disk.


Video mode (Coco 3)
-------------------

By default SDCFLASH will use the RGB palette on a Coco 3. Press SHIFT-V to toggle 
betweem composite and RGB video modes. To make the composite video mode permanent,
set the CO variable to 1 on line 10 in SDCFLASH.BAS.


ROM sets included
-----------------

1. Applications

ARTGALRY.ROM - Art Gallery (1981) (26-3061) (Tandy)
CLRFILE..ROM - Color File (1981) (26-3103) (Tandy)
CLRFILE2.ROM - Color File II (1986) (26-3110) (Tandy) (6847T1)
DIAGS....ROM - Diagnostics (1980) (26-3019) (Tandy)
DIAGSV2..ROM - Diagnostics v2.0 (1982) (26-3019) (Tandy)
FINANCE..ROM - Personal Finance (1980) (26-3101) (Tandy)
FINANCE2.ROM - Personal Finance II (1983) (26-3106) (Tandy)
GRAPHIC..ROM - Graphic Pak (1982) (26-3157) (Tandy)
HANDYMAN.ROM - Handyman (1981) (26-3154) (Tandy)
PAINTER..ROM - Micro Painter (1982) (26-3077) (Tandy)
SCRIPSIT.ROM - Color Scripsit (1981) (26-3105) (Tandy)
SCRIPSI2.ROM - Color Scripsit II (1986) (26-3109) (Tandy) (6847T1)
SPECTACU.ROM - Spectaculator (1983) (26-3104) (Tandy)
TYPEMATE.ROM - TypeMate (1988) (26-3155) (Tandy)
TYPTUTOR.ROM - Typing Tutor (1980) (26-3152) (Tandy)
VIDEOTEX.ROM - Videotex v1.2 (1981) (26-2222) (Tandy)

2. Coco 3 Games

MALCOM...ROM - A Mazing World of Malcom Mortar (1987) (26-3160) (Tandy) (Coco 3)
SHANGHAI.ROM - Shanghai (1987) (26-3084) (Tandy) (Coco 3)
SPRING...ROM - Springster (1987) (26-3078) (Tandy) (Coco 3)
THAROGGA.ROM - Castle of Tharoggad (1988) (26-3159) (Tandy) (Coco 3)
THEXDER..ROM - Thexder (1987) (26-3072) (Tandy) (Coco 3)

3. CP-400 Applications

EDITOR...ROM - Editor (Prosoft) (Brazilian clone of Color Scripsit)
FINANCAS.ROM - Finanças (Prosoft) (Brazilian clone of Personal Finance)
GRAFICOS.ROM - Gráficos (Prosoft) (Brazilian clone of Graphic Pak)
PROCALC..ROM - Procalc (Prosoft) (Brazilian clone of Spectaculator)

4. CP-400 Games

ATAQUE...ROM - Ataque (Prosoft) (Brazilian clone of Galactic Attack)
BATIDA...ROM - Batida (Prosoft) (Brazilian clone of Bustout)
BINGO....ROM - Bingo (Prosoft) (Brazilian clone of  Bingo Math)
CASTELO..ROM - Castelo (Prosoft) (Brazilian clone of Castle Guard)
DAMAS....ROM - Damas (Prosoft) (Brazilian clone of  Checkers)
DEFENSOR.ROM - Defensor Gal ctico (Prosoft) (Brazilian clone of Starblaze)
DINO.....ROM - Dinossauros (Prosoft) (Brazilian clone of Dino Wars)
ESCALADA.ROM - Escalada (Prosoft) (Brazilian clone of Canyon Climber)
ESQUI....ROM - Esqui (Prosoft) (Brazilian clone of Skiing)
FLIPER...ROM - Fliper (Prosoft) (Brazilian clone of Pinball )
ILHAS....ROM - Ilhas (Prosoft) (Brazilian clone of Polaris)
INVASORE.ROM - Invasores (Prosoft) (Brazilian clone of Space Assault)
LABIRINT.ROM - Labirinto (Prosoft) (Brazilian clone of Monster Maze)
METEORO..ROM - Meteoro (Prosoft) (Brazilian clone of  Microbes)
NEBULA...ROM - Nebula (Prosoft) (Brazilian clone of Project Nebula)
PEGACOME.ROM - Pegacome (Prosoft) (Brazilian clone of Mega-Bug)
PIPOCA...ROM - Pipoca (Prosoft) (Brazilian clone of Popcorn)
RALLY....ROM - Rally da Demoli‡Æo (Prosoft) (Brazilian clone of Demolition Derby)
SALTIM...ROM - Saltimbanco (Prosoft) (Brazilian clone of Clowns & Balloons)
TENIS....ROM - Tênis (Prosoft) (Brazilian clone of Tennis)
TERROR...ROM - Terror (Prosoft) (Brazilian clone of Poltergeist)
TIROALVO.ROM - Tiro ao Alvo (Prosoft) (Brazilian clone of Shooting Gallery)
XADREZ...ROM - Xadrez (Prosoft) (Brazilian clone of Micro Chess v2.0)

5. Disk Basic

DISK10...ROM - Color Computer Disk BASIC V1.0 (1982) (26-3022) (Tandy)
DISK11...ROM - Color Computer Disk BASIC V1.1 (1982) (26-3022) (Tandy)
DISK11SD.ROM - Color Computer Disk BASIC for FD502 (1982) (26-3131) (Tandy)

6. Educational

BINGO....ROM - Bingo Math (1980) (26-3150) (Tandy)
FACEMAKR.ROM - Facemaker (1984) (26-3166) (Spinnaker)
FRACTION.ROM - Fraction Fever (1984) (26-3169) (Spinnaker)
KIDSKEYS.ROM - Kids on Keys (1984) (26-3167) (Spinnaker)
KINDER...ROM - Kindercomp (1984) (26-3168) (Spinnaker)
MATHTUT..ROM - Math Tutor (1988) (26-3148) (Tandy)
ROBOTBTL.ROM - Color Robot Battle (1981) (26-3070) (Tandy)

7. Games #1

7CARD....ROM - 7 Card Stud (1983) (26-3074) (Tandy)
ANDRONE..ROM - Androne (1983) (26-3096) (Tandy)
ARKANOID.ROM - Arkanoid (1987) (26-3043) (Tandy) (Coco 1-2 version)
ASSAULT..ROM - Space Assault (1981) (26-3060) (Tandy)
ATOM.....ROM - Atom (1983) (26-3149) (Tandy)
BACKGAM..ROM - Backgammon (1980) (26-3059) (Tandy)
BASEBALL.ROM - Color Baseball (1980) (26-3095) (Tandy)
BRIDGE...ROM - Bridge Tutor I (1982) (26-3158) (Tandy)
BUSTOUT..ROM - Bustout (1981) (26-3056) (Tandy)
CANYON...ROM - Canyon Climber (1982) (26-3089) (Tandy)
CASTLE...ROM - Castle Guard (1981) (26-3079) (Tandy)
CHECKERS.ROM - Checker King (1980) (26-3055) (Tandy)
CHESS....ROM - Micro Chess v2.0 (1980) (26-3050) (Tandy)
CLOWNS...ROM - Clowns & Balloons (1982) (26-3087) (Tandy)
CROSSWOR.ROM - Crosswords (1981) (26-3082) (Tandy)
CUBES....ROM - Color Cubes (1981) (26-3075) (Tandy)
CYRUS....ROM - Cyrus World Class Chess (1983) (26-3064) (Tandy)

8. Games #2

DAGGOFIX.ROM - Dungeons of Daggorath (Shield Fix) (Aaron Oliver)
DAGGORAT.ROM - Dungeons of Daggorath (1982) (26-3093) (Tandy)
DBLBACK..ROM - Doubleback (1982) (26-3091) (Tandy)
DEMON....ROM - Demon Attack (1984) (26-3099) (Tandy)
DERBY....ROM - Demolition Derby (1984) (26-3044) (Tandy)
DINOWARS.ROM - Dino Wars (1981) (26-3057) (Tandy)
DON-PAN..ROM - DON-PAN (1984) (26-3097) (Tandy)
DOODLE...ROM - Doodle Bug (1982) (Computerware)
DOWNLAND.ROM - Downland v1.1 (1983) (26-3046) (Tandy)
DRAGON...ROM - Dragon Fire (1984) (26-3098) (Tandy)
FOOTBALL.ROM - Football (1980) (26-3053) (Tandy)
GALACTIC.ROM - Galactic Attack (1982) (26-3066) (Tandy)
GINCHAMP.ROM - Gin Champion (1982) (26-3083) (Tandy)
GOMOKU...ROM - Gomoku-Renju (1983) (26-3069) (Tandy)
LIFELINE.ROM - Stellar Lifeline (1983) (26-3047) (Tandy)

9. Games #3

MEGABUG..ROM - Mega-Bug (1982) (26-3076) (Tandy)
MICROBES.ROM - Microbes (1981) (26-3085) (Tandy)
MONSTER..ROM - Monster Maze (1983) (26-3081) (Tandy)
NEBULA...ROM - Project Nebula (1981) (26-3063) (Tandy)
NEREIS...ROM - Slay the Nereis (1983) (26-3086) (Tandy)
PANIC....ROM - Panic Button (1983) (26-3147) (Tandy)
PINBALL..ROM - Pinball (1980) (26-3052) (Tandy)
POLARIS..ROM - Polaris (1981) (26-3065) (Tandy)
POLTER...ROM - Poltergeist (1982) (26-3073) (Tandy)
POPCORN..ROM - Popcorn (1981) (26-3090) (Steve Bjork)
QUASAR...ROM - Quasar Commander (1980) (26-3051) (Tandy)
REACTOID.ROM - Reactoid (1983) (26-3092) (Tandy)
ROMAN....ROM - Roman Checkers (1981) (26-3071) (Tandy)
SHOOTING.ROM - Shooting Gallery (1982) (26-3088) (Tandy)
SILPHEED.ROM - Silpheed (1988) (26-3054) (Tandy) (Coco 1-2 version)
SKIING...ROM - Skiing (1981) (26-3058) (Tandy)
SOKO-BAN.ROM - Soko-Ban (1988) (26-3161) (Tandy)
SPIDER...ROM - Spidercide (1983) (26-3049) (Tandy)

10. Games #4

STARBLAZ.ROM - Starblaze (1983) (26-3094) (Tandy)
TEMPLE...ROM - Temple of ROM (1984) (26-3045) (Tandy)
TENNIS...ROM - Tennis (1981) (26-3080) (Tandy)
TETRIS...ROM - Tetris (1987) (26-3163) (Tandy) (Coco 1-2) (Coco 3)
WILDCAT..ROM - Wildcatting (1982) (26-3067) (Tandy)

11. Hardware

APPLIGHT.ROM - Appliance and Light Controller (1984) (26-3142) (Tandy) (Coco 1-2)
MODEM....ROM - Direct Connect Modem Pak (1985) (26-2228) (Tandy)
ORCH90...ROM - Orchestra 90-CC (1984) (26-3143) (Tandy)
RS-232...ROM - Deluxe RS-232 Program Pak (1983) (26-2226) (Tandy)

12. HDB-DOS

HDBDW3C1.ROM - HDB-DOS for Drivewire 3 (Coco 1) (Cloud-9)
HDBDW3C2.ROM - HDB-DOS for Drivewire 3 (Coco 2) (Cloud-9)
HDBDW3C3.ROM - HDB-DOS for Drivewire 3 (Coco 3) (Cloud-9)
HDBDW4C2.ROM - HDB-DOS for Drivewire 4 (Coco 2) (Cloud-9)
HDBDW4C3.ROM - HDB-DOS for Drivewire 4 (Coco 3) (Cloud-9)
HDBSDC...ROM - HDB-DOS for the Coco SDC (Cloud-9)

13. JDOS

JDOS108..ROM - JDOS v1.08 (1983) (J&M Systems)
JDOS110..ROM - JDOS v1.10 (1983) (J&M Systems)
JDOS111..ROM - JDOS v1.11 (1983) (J&M Systems)
JDOS123..ROM - JDOS v1.23 (1985) (J&M Systems)

14. Music

AUDIO....ROM - Audio Spectrum Analyzer (1981) (26-3156) (Tandy) (Coco 1-2)
AUDIO83..ROM - Audio Spectrum Analyzer (1983) (26-3156) (Tandy)
MUSIC....ROM - Music (1980) (26-3151) (Tandy)
ORC90DAC.ROM - Orchestra 90-CC (1984) (26-3143) (Tandy) (DAC version)

15. New Games

COLOR8...ROM - Color Eights 0.1.12 (Pierre Sarrazin)
FAHRFALL.ROM - Fahrfall (Pandemic Edition) (John W. Linville)
FLAGON...ROM - Flagon Bird 1.1 (Basco)
FLOODIT..ROM - Flood It! (Evan C. Wright)
NYANCAT..ROM - Nyan Cat (Ciaran Anscomb) (Coco 1-2)
TRISLAND.ROM - Treasure Island Defence (Sheldon MacDonald) (Coco 3)
XMASRUSH.ROM - Xmas Rush (John Linville)

16. Programming

EDTASM...ROM - EDTASM+ (1982) (26-3250) (Tandy)
FORTH....ROM - Color Forth (1981) (Microworks)
LOGO.....ROM - Color Logo (1983) (26-2722) (Tandy)
LOGOFR...ROM - Color Logo (French) (1983) (26-2722) (Tandy)
SDS80C...ROM - SDS80C (1981) (The Micro Works)
SUPRLOGO.ROM - Super Logo (1984) (26-2717) (Tandy)

17. SDC-DOS

SDCDOS12.ROM - SDC-DOS 1.2 (Darren Atkinson)
SDCDOS13.ROM - SDC-DOS 1.3 (Darren Atkinson)
SDCDOS14.ROM - SDC-DOS 1.4 (Darren Atkinson)
SDCDOS15.ROM - SDC-DOS 1.5 (Darren Atkinson)
SDCDOS16.ROM - SDC-DOS 1.6 (Darren Atkinson)


Files description
-----------------

sdcflash.dsk - SDCFLASH disk
readme.txt   - This file
changes.txt  - Changes history


I hope you will find this program useful. Please contact me if you find a bug 
or have any suggestions!

guillaume.major@gmail.com
2022.01.05