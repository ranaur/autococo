
SDSK Release 2 - a replacement for OS9Level1 CCDISK. This will allow OS9 
Level 1 (v1 or v2) to format and boot from double sided double density 
floppies. The disk contains also Bootfix, and utility that must run after 
the Installation of SDSK to fix the boot record, otherwise the new OS9 
system won't boot.
