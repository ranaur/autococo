
Tandy Diagnostic Utilities

- Tandy Drive Controller (CCTDC)
- FDC alignment software (FDCALG)
- Color Disk Drive Diagnostics (FDCTST)
- Expansion Box Diagnostic Test (XBOXTEST)
